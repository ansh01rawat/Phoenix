import type { Product } from '../types'

type Props = { products?: Product[] }

export function ProductGrid({ products }: Props) {
  return (
    <section className="product-grid">
      {products!.map((product) => (
        <article key={product.id}>
          <h2>{product.name}</h2>
          <p>{product.price}</p>
        </article>
      ))}
    </section>
  )
}
import { ProductGrid } from '../components/ProductGrid'
import { useProducts } from '../hooks/useProducts'

export function Home() {
  const products = useProducts()
  return <ProductGrid products={products.data} />
}